import { useState } from "react";

import useAppToast from "../../../hooks/useAppToast";

const useForgotPassword = () => {
  const { toast } = useAppToast();

  const [identifier, setIdentifier] = useState("");
  const [fieldError, setFieldError] = useState("");

  const icon = identifier.includes("@") ? "mail" : "person";

  const handleChange = (event) => {
    setIdentifier(event.target.value);
    setFieldError("");
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!identifier.trim()) {
      setFieldError("Vui lòng nhập email hoặc mã nhân viên.");
      return;
    }

    toast.info(
      "Chưa hỗ trợ backend",
      "Backend hiện chưa có API quên mật khẩu nên màn này chỉ dựng UI trước.",
      4000,
    );
  };

  return {
    identifier,
    icon,
    fieldError,
    isLoading: false,
    handleChange,
    handleSubmit,
  };
};

export default useForgotPassword;
